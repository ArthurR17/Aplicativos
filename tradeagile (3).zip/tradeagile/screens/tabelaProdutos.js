import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, ImageBackground, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TabelaProdutos = ({ navigation }) => {
  const [produtos, setProdutos] = useState([]);

  useEffect(() => {
    const loadProdutos = async () => {
      try {
        const storedProdutos = await AsyncStorage.getItem('produtos');
        const parsedProdutos = storedProdutos ? JSON.parse(storedProdutos) : [];
        setProdutos(parsedProdutos);
      } catch (error) {
        console.error('Failed to load products:', error);
      }
    };

    loadProdutos();
  }, []);

  return (
    <ImageBackground
      style={styles.back}
      source={require('../assets/fundo.png')}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />
        <Text style={styles.title}>Tabela de Produtos</Text>
        <ScrollView horizontal={true} style={styles.tableContainer}>
          <View style={styles.table}>
            <View style={styles.headerRow}>
              <Text style={styles.headerCell}>Produto</Text>
              <Text style={styles.headerCell}>Preço</Text>
              <Text style={styles.headerCell}>Empresa</Text>
              <Text style={styles.headerCell}>Subcategoria</Text>
              <Text style={styles.headerCell}>Fornecedor</Text>
              <Text style={styles.headerCell}>Imagem</Text>
            </View>
            {produtos.length === 0 ? (
              <Text style={styles.emptyMessage}>Nenhum produto cadastrado.</Text>
            ) : (
              produtos.map((produto) => (
                <View key={produto.id} style={styles.row}>
                  <Text style={styles.cell}>{produto.name}</Text>
                  <Text style={styles.cell}>
                    R$ {produto.price ? produto.price.toFixed(2) : '0.00'}
                  </Text>
                  <Text style={styles.cell}>{produto.company}</Text>
                  <Text style={styles.cell}>{produto.subCategory}</Text>
                  <Text style={styles.cell}>{produto.supplier}</Text>
                  {produto.image ? (
                    <Image source={{ uri: produto.image }} style={styles.productImage} />
                  ) : (
                    <Text style={styles.cell}>Sem imagem</Text>
                  )}
                </View>
              ))
            )}
          </View>
        </ScrollView>
              <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('OpcoesFunc')}>
        <Text style={styles.botao}>Voltar</Text>
      </TouchableOpacity>
      </ScrollView>

      
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
    botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },

  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#FFFFFF',
    textAlign: 'center',
  },
  tableContainer: {
    marginBottom: 30,
    marginRight: 35,
  },
  table: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  headerRow: {
    flexDirection: 'row',
    backgroundColor: '#1E5E8B',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#0056b3',
  },
  headerCell: {
    flex: 1,
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 16,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: 'row',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  cell: {
    flex: 1,
    color: '#333',
    textAlign: 'center',
    fontSize: 14,
    paddingHorizontal: 5,
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
    backgroundColor: '#eee',
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#888',
    marginVertical: 20,
    fontSize: 16,
    fontStyle: 'italic',
  },
  image: {
    width: 300,
    height: 200,
    marginBottom: 30,
    borderRadius: 20,
  },
  back: {
    zIndex: -1,
    width: '110%',
    height: '100%',
    position: 'absolute',
  },
});

export default TabelaProdutos;
