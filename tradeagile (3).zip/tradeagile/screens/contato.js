import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Alert, Image } from 'react-native';

const Contato = ({ navigation }) => {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');
  const [mensagem, setMensagem] = useState('');

  const handleEnviar = () => {
    if (nome === '' || telefone === '' || email === '' || mensagem === '') {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
    } else {
      Alert.alert('Sucesso', 'Sua mensagem foi enviada com sucesso!');
      navigation.navigate('OpcoesCli');
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground style={styles.back} source={require('../assets/fundo.png')} />
              <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />

      <Text style={styles.title}>Contato</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome"
                placeholderTextColor="black"
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        style={styles.input}
        placeholder="Telefone"
                placeholderTextColor="black"
        value={telefone}
        onChangeText={setTelefone}
        keyboardType="phone-pad"
      />

      <TextInput
        style={styles.input}
        placeholder="Email"
                placeholderTextColor="black"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <TextInput
        style={styles.textArea}
        placeholder="Digite sua mensagem..."
                placeholderTextColor="black"

        value={mensagem}
        onChangeText={setMensagem}
        multiline={true}
        numberOfLines={4}
      />

      <TouchableOpacity style={styles.buttonContainer} onPress={handleEnviar}>
        <Text style={styles.buttonText}>Enviar</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('OpcoesCli')}>
        <Text style={styles.botao}>Voltar</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
    image: {
    width: 300,
    height: 200,
    marginBottom: 30,
    borderRadius: 20,
  },
  
        botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9EB9CC',
  },
  back: {
    zIndex: -1,
    width: '110%',
    height: '111%',
    position: 'absolute',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 50,
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 15,
    borderWidth: 2,
    elevation: 3,
    fontSize: 16,
    fontFamily: 'Roboto',
    color: '#000',
  },
  textArea: {
    width: '80%',
    height: 120,
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 15,
    paddingTop: 15,
    borderWidth: 2,
    elevation: 3,
    fontSize: 16,
    fontFamily: 'Roboto',
    color: '#000',
  },
  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginTop: 20,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
    textAlign: 'center',
  },
});

export default Contato;
