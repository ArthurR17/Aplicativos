// Importação das bibliotecas do react
import React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, ImageBackground } from 'react-native';

const Home = ({ navigation }) => {

  return (
    <View style={styles.container}>
    <Text style={styles.titulo} >Bem-Vindo à Trade.Agile!</Text>
      <ImageBackground
        style={styles.back}
        source={require('../assets/fundo.png')}
      />
      <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />
      
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.buttonText}>Cliente</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('LoginFunc')}>
          <Text style={styles.buttonText}>Funcionário</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default Home;

const styles = StyleSheet.create({
  titulo: {
    fontSize: 36,
    fontFamily: 'Roboto',
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    top: -40,
  },

  back: {
    zIndex: -1,
    width: '100%',
    height: '101%',
    position: 'absolute',
  },

  image: {
    width: 250,
    height: 150,
    marginBottom: 90,
    resizeMode: 'contain',
  },


  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#004AAD',
  },
  

  buttonContainer: {
    position: 'absolute',
    bottom: 250,
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
  },

  button: {
    backgroundColor: '#FFFFFF',
    borderColor: '#004AAD',
    borderWidth: 2,
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 20,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonText: {
    color: '#004AAD',
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: 'Roboto',
  },
});
