import React, { useState } from 'react';
import { View, Text, Image, ScrollView, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';

const productImages = {
  '1': require('../assets/suco.jpg'),
  '2': require('../assets/cocktail.jpg'),
  '3': require('../assets/refrigerantes.jpg'),
  '4': require('../assets/kafta.jpg'),
  '5': require('../assets/espeto.jpg'),
  '6': require('../assets/medalhao.jpg'),
  '7': require('../assets/pudim.webp'),
  '8': require('../assets/brigadeiro.jpg'),
  '9': require('../assets/torta.jpg'),
  '11': require('../assets/urso.jpg'),
  '12': require('../assets/dino.webp'),
  '13': require('../assets/coelho.png'),
  '14': require('../assets/barbie.jpg'),
  '15': require('../assets/bebe.jpg'),
  '16': require('../assets/polly.webp'),
  '17': require('../assets/mcqueen.webp'),
  '18': require('../assets/carrinho.webp'),
  '19': require('../assets/minitruck.jpg'),
  '20': require('../assets/monitor1.jpg'),
  '21': require('../assets/monitor2.jpg'),
  '22': require('../assets/monitor3.jpg'),
  '23': require('../assets/rtx.jpg'),
  '24': require('../assets/intel.jpg'),
  '25': require('../assets/placa.jpg'),
  '26': require('../assets/headset.jpg'),
  '27': require('../assets/mouse.jpg'),
  '28': require('../assets/teclado.jpg'),
  '29': require('../assets/kitinverno.png'),
  '30': require('../assets/moletom.png'),
  '31': require('../assets/jaquetainverno.png'),
  '32': require('../assets/oculos.png'),
  '33': require('../assets/regata.png'),
  '34': require('../assets/maio.png'),
  '35': require('../assets/vestido.png'),
  '36': require('../assets/tenisapple.png'),
  '37': require('../assets/bolsa.png'),

};

const logos = {
  DrinkAgile: require('../assets/drinkagile.png'),
  ToyAgile: require('../assets/toyagile.jpg'),
  DevAgile: require('../assets/devagile.png'),
  STARFASHION: require('../assets/starfashion.png'),
};

const products = {
  DrinkAgile: {
    Bebidas: [
      { id: '1', name: 'Suco', price: 6, image: productImages['1'] },
      { id: '2', name: 'Cocktail', price: 25, image: productImages['2'] },
      { id: '3', name: 'Refrigerantes', price: 10, image: productImages['3'] },
    ],
    Espetos: [
      { id: '4', name: 'Kafta', price: 7, image: productImages['4'] },
      { id: '5', name: 'Carne', price: 5, image: productImages['5'] },
      { id: '6', name: 'Medalhão', price: 10, image: productImages['6'] },
    ],
    Doces: [
      { id: '7', name: 'Pudim', price: 20, image: productImages['7'] },
      { id: '8', name: 'Brigadeiro', price: 2, image: productImages['8'] },
      { id: '9', name: 'Torta', price: 35, image: productImages['9'] },
    ]
  },
  ToyAgile: {
    Pelúcias: [
      { id: '10', name: 'Urso', price: 50, image: productImages['11'] },
      { id: '11', name: 'Dinossauro', price: 45, image: productImages['12'] },
      { id: '12', name: 'Coelho', price: 35, image: productImages['13'] },
    ],
    Bonecas: [
      { id: '13', name: 'Barbie', price: 389, image: productImages['14'] },
      { id: '14', name: 'Bebê Reborn', price: 405, image: productImages['15'] },
      { id: '15', name: 'Polly', price: 79, image: productImages['16'] },
    ],
    Carrinhos: [
      { id: '16', name: 'McQueen', price: 59, image: productImages['17'] },
      { id: '17', name: 'Carrinho de Controle remoto', price: 150, image: productImages['18'] },
      { id: '18', name: 'Carrinho de Fricção', price: 25, image: productImages['19'] },
    ]
  },
  DevAgile: {
    Monitores: [
      { id: '19', name: 'Monitor Gamer LG 27 Polegadas', price: 899, image: productImages['20'] },
      { id: '20', name: 'Monitor Gamer Asus 24 Polegadas 165hz', price: 2199, image: productImages['21'] },
      { id: '21', name: 'Monitor Positivo 17 Polegadas 30hz', price: 7999, image: productImages['22'] },
    ],
    Hardware: [
      { id: '22', name: 'RTX 3060 12GB GDDR6', price: 1950, image: productImages['23'] },
      { id: '23', name: 'Processador Intel Core I9 12900KF 5.2GHZ', price: 2100, image: productImages['24'] },
      { id: '24', name: 'Placa Mãe Asus ROG DDR5', price: 4200, image: productImages['25'] },
    ],
    Acessórios: [
      { id: '25', name: 'Headset Redragon Zeus X RGB', price: 199, image: productImages['26'] },
      { id: '26', name: 'Mouse Gamer Redragon Cobra RGB', price: 99, image: productImages['27'] },
      { id: '27', name: 'Teclado Gamer Redragon K571', price: 200, image: productImages['28'] },
    ]
  },
  STARFASHION: {
    Inverno: [
      { id: '28', name: 'Kit de Inverno', price: 79, image: productImages['29'] },
      { id: '29', name: 'Moletom', price: 149, image: productImages['30'] },
      { id: '30', name: 'Jaqueta Feminina', price: 199, image: productImages['31'] },
    ],
    Verão: [
      { id: '31', name: 'Óculos Escuro', price: 120, image: productImages['32'] },
      { id: '32', name: 'Regata', price: 35, image: productImages['33'] },
      { id: '33', name: 'Maiô', price: 39, image: productImages['34'] },
    ],
    Diversos: [
      { id: '34', name: 'Vestido', price: 150, image: productImages['35'] },
      { id: '35', name: 'Tênis Apple', price: 399, image: productImages['36'] },
      { id: '36', name: 'Bolsa', price: 399, image: productImages['37'] },
    ]
  }
};

const Produtos = ({ navigation }) => {
  const [category, setCategory] = useState('DrinkAgile');
  const [subCategory, setSubCategory] = useState(Object.keys(products[category])[0]);
  const [cart, setCart] = useState([]);

  const handleAddToCart = (productId) => {
    const product = products[category]?.[subCategory]?.find(p => p.id === productId);
    if (!product) return;

    const existingProduct = cart.find(item => item.id === productId);
    if (existingProduct) {
      setCart(cart.map(item => 
        item.id === productId ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const renderSubCategorySelector = () => (
    <View style={styles.subCategoryContainer}>
      {Object.keys(products[category]).map((sub) => (
        <TouchableOpacity 
          key={sub}
          style={[styles.subCategoryButton, subCategory === sub && styles.selectedSubCategoryButton]} 
          onPress={() => setSubCategory(sub)}
        >
          <Text style={[styles.subCategoryText, subCategory === sub && styles.selectedSubCategoryText]}>{sub}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <ImageBackground source={require('../assets/fundo.png')} style={styles.background}>
      <View style={styles.container}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.menuContainer}>
          {Object.keys(products).map((cat) => (
            <TouchableOpacity 
              key={cat}
              style={[styles.menuButton, category === cat && styles.selectedMenuButton]} 
              onPress={() => {
                setCategory(cat);
                setSubCategory(Object.keys(products[cat])[0]);
              }}
            >
              <Text style={[styles.menuText, category === cat && styles.selectedMenuText]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <ScrollView style={styles.scrollContainer}>
          <View style={styles.header}>
            <Image source={logos[category]} style={styles.logo} />
            <Text style={styles.title}>{category.toUpperCase()}</Text>
            {renderSubCategorySelector()}
          </View>
          {products[category]?.[subCategory]?.map(product => (
            <View key={product.id} style={styles.product}>
              <Image source={product.image} style={styles.image} />
              <View style={styles.details}>
                <Text style={styles.name}>{product.name.toUpperCase()}</Text>
                <Text style={styles.price}>R$ {product.price.toFixed(2)}</Text>
                <TouchableOpacity style={styles.button} onPress={() => handleAddToCart(product.id)}>
                  <Text style={styles.buttonText}>Adicionar ao Carrinho</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
        <View style={styles.checkoutButton}>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Checkout', { cart })}>
            <Text style={styles.buttonText}>Finalizar Pedido</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '101%',
    position: 'absolute',
    top: -2,
  },
  container: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  menuContainer: {
    flexDirection: 'row',
    paddingVertical: 10,
    marginTop: 35,
    height: 80, 
    overflow: 'visible', 
  },
  menuButton: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginHorizontal: 5,
    backgroundColor: '#004AAD',
    borderRadius: 5,
  },
  selectedMenuButton: {
    backgroundColor: '#1E5E8B',
  },
  menuText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  selectedMenuText: {
    color: '#FFDE59',
  },
  scrollContainer: {
    flexGrow: 1, 
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginVertical: 30,
  },
  logo: {
    width: 200,
    height: 170,
    borderRadius: 75,
    marginBottom: 10,
    bottom: 35,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
  },
  subCategoryContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  subCategoryButton: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginHorizontal: 5,
    backgroundColor: '#1E5E8B',
    borderRadius: 5,
  },
  selectedSubCategoryButton: {
    backgroundColor: '#004AAD',
  },
  subCategoryText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedSubCategoryText: {
    color: '#FFDE59',
  },
  product: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#9EB9CC',
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginRight: 20,
  },
  details: {
    flex: 1,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color:'black',
  },
  price: {
    fontSize: 16,
    color: 'black',
  },
  button: {
    marginTop: 10,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#004AAD',
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    
  },
  checkoutButton: {
    padding: 20,
    
  },
});

export default Produtos;
