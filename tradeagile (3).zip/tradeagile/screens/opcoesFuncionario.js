import React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, ImageBackground, ScrollView, Alert } from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';


const OpcoesFunc = ({ navigation }) => {
  const premium = () => {
    Alert.alert('Trade.Agile Premium não detectado!', 'Para acessar está área, você precisa adiquirir a versão Premium do nosso aplicativo');
  }
  return (
    <View style={styles.container}>
      <ImageBackground style={styles.back} source={require('../assets/fundo.png')} />

      <Image style={styles.logo} source={require('../assets/trade.agilefundo.png')} />

      <TouchableOpacity style={styles.barra}>
        <FontAwesome name="bars" size={45} color="white" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.voltar}>
        <FontAwesome5 name="bell" size={45} color="white" />
      </TouchableOpacity>

      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.optionContainer}>
          <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('CadastroProd')}>
            <View style={styles.optionBackground}>
              <FontAwesome5 name="shopping-bag" size={45} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Cadastro de Produtos</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('CadastroForn')}>
            <View style={styles.optionBackground}>
              <FontAwesome5 name="truck" size={45} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Cadastro de Fornecedores</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('TabelaProd')}>
            <View style={styles.optionBackground}>
              <FontAwesome5 name="table" size={45} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Tabela dos Produtos</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('TabelaForn')}>
            <View style={styles.optionBackground}>
              <FontAwesome name="table" size={40} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Tabela de Fornecedores</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={premium}>
            <View style={styles.optionBackgroundPremium}>
              <FontAwesome name="table" size={45} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Tabela de Clientes</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={premium}>
            <View style={styles.optionBackgroundPremium}>
              <FontAwesome5 name="money-bill-wave" size={45} color="#FFFFFF" />
            </View>
            <Text style={styles.optionText}>Financeiro</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <FontAwesome name="home" size={40} color="#FFFFFF" />
        </TouchableOpacity>
        <TouchableOpacity>
          <FontAwesome name="user" size={40} color="#FFFFFF" />
        </TouchableOpacity>
        <TouchableOpacity>
          <FontAwesome name="cog" size={40} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default OpcoesFunc;

const styles = StyleSheet.create({
  optionBackgroundPremium:{
    width: 100,
    height: 100,
    backgroundColor: 'grey',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    borderColor: 'black', 
    borderWidth: 2,
  },
  container: {
    flex: 1,
    alignItems: 'center',
  },

  scrollContainer: {
    paddingBottom: 100, 
  },

  back: {
    zIndex: -1,
    width: '100%',
    height: '100%',
    position: 'absolute',
    bottom: 20,
  },

  optionContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    width: '90%',
    marginTop: 20,
    left: 20,
  },

  option: {
    width: '40%',
    alignItems: 'center',
    marginVertical: 20,
  },

optionBackground: {
   width: 100,
   height: 100,
   backgroundColor: '#1E5E8B',
   borderRadius: 20,
   justifyContent: 'center',
   alignItems: 'center',
   elevation: 5,
   borderColor: '#FFDE59', 
   borderWidth: 2,
},


  optionText: {
    marginTop: 10,
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Roboto',
  },

  logo: {
    width: 250,
    height: 200,
    marginTop: 100,
  },

  barra: {
    position: 'absolute',
    marginTop: 50,
    right: 20,
  },

  voltar: {
    position: 'absolute',
    left: 20,
    marginTop: 50,
  },

  footer: {
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    backgroundColor: '#1E5E8B',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#004AAD',
  },
});
