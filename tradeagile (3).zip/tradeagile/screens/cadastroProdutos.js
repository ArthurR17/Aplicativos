import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, TouchableOpacity, Image, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';

const CadastroProduto = ({ navigation }) => {
    // Estados para os campos do formulário
  const [nomeProduto, setNomeProduto] = useState('');
  const [precoProduto, setPrecoProduto] = useState('');
  const [imagemProduto, setImagemProduto] = useState('');
  const [empresa, setEmpresa] = useState('');
  const [subCategoria, setSubCategoria] = useState('');
  const [fornecedor, setFornecedor] = useState('');
  const [fornecedores, setFornecedores] = useState([]);
  const [subcategorias, setSubcategorias] = useState([]);

    // Mapeia empresas para suas subcategorias
  const empresasSubcategorias = {
    'Drink.Agile': ['Espeto', 'Bebidas', 'Doces'],
    'Dev.Agile': ['Software', 'Hardware', 'Consultoria'],
    'Toy.Agile': ['Brinquedo', 'Carrinhos', 'Bonecas'],
    'Star Fashion': ['Roupas', 'Acessórios', 'Calçados'],
  };

    // Carrega fornecedores armazenados no AsyncStorage
  useEffect(() => {
    const loadFornecedores = async () => {
      try {
        const storedFornecedores = await AsyncStorage.getItem('fornecedores');
        const parsedFornecedores = storedFornecedores ? JSON.parse(storedFornecedores) : [];
        setFornecedores(parsedFornecedores);
      } catch (error) {
        console.error('Failed to load suppliers:', error);
      }
    };

    loadFornecedores();
  }, []);

    // Atualiza as subcategorias com base na empresa selecionada
  const handleEmpresaChange = (selectedEmpresa) => {
    setEmpresa(selectedEmpresa);
    setSubCategoria('');
    setSubcategorias(empresasSubcategorias[selectedEmpresa] || []);
  };

    // Cadastra um novo produto e salva no AsyncStorage
  const handleCadastro = async () => {
    const novoProduto = {
      id: Date.now().toString(),
      name: nomeProduto,
      price: parseFloat(precoProduto),
      image: imagemProduto,
      company: empresa,
      subCategory: subCategoria,
      supplier: fornecedor,
    };

    try {
      const produtosExistentes = await AsyncStorage.getItem('produtos');
      const produtos = produtosExistentes ? JSON.parse(produtosExistentes) : [];

      produtos.push(novoProduto);

      await AsyncStorage.setItem('produtos', JSON.stringify(produtos));

      Alert.alert('Sucesso', 'Produto cadastrado com sucesso!');
      navigation.navigate('OpcoesFunc');
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível cadastrar o produto.');
    }
  };

  return (
    <View style={styles.container}>
          <ImageBackground
        style={styles.back}
        source={require('../assets/fundo.png')}
      />

      <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />
      
      <TextInput
        style={styles.input}
        placeholder="Nome do Produto"
                        placeholderTextColor="black"

        value={nomeProduto}
        onChangeText={setNomeProduto}
      />
      
      <TextInput
        style={styles.input}
        placeholder="Preço do Produto"
                        placeholderTextColor="black"

        value={precoProduto}
        onChangeText={setPrecoProduto}
        keyboardType="numeric"
      />
      
      <TextInput
        style={styles.input}
        placeholder="Link da Imagem do Produto (Opcional)"
                        placeholderTextColor="black"

        value={imagemProduto}
        onChangeText={setImagemProduto}
      />

      <Picker
        selectedValue={empresa}
        style={styles.picker}
        onValueChange={handleEmpresaChange}
      >
        <Picker.Item label="Selecione uma Empresa" value="" />
        {Object.keys(empresasSubcategorias).map(empresa => (
          <Picker.Item key={empresa} label={empresa} value={empresa} />
        ))}
      </Picker>

      <Picker
        selectedValue={subCategoria}
        style={styles.picker}
        onValueChange={(itemValue) => setSubCategoria(itemValue)}
        enabled={subcategorias.length > 0}
      >
        <Picker.Item label="Selecione uma Subcategoria" value="" />
        {subcategorias.map(sub => (
          <Picker.Item key={sub} label={sub} value={sub} />
        ))}
      </Picker>

      <Picker
        selectedValue={fornecedor}
        style={styles.picker}
        onValueChange={(itemValue) => setFornecedor(itemValue)}
      >
        <Picker.Item label="Selecione um Fornecedor" value="" />
        {fornecedores.map(f => (
          <Picker.Item key={f.id} label={f.name} value={f.name} />
        ))}
      </Picker>

      <TouchableOpacity style={styles.buttonContainer} onPress={handleCadastro}>
        <Text style={styles.botao}>Cadastrar Produto</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
    back: {
    zIndex: -1,
    width: '110%',
    height: '110%',
    position: 'absolute',
  },

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9EB9CC',
    padding: 20,
  },

  input: {
    width: '80%',
    height: 50,
    color: '#000000',
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderWidth: 2,
    elevation: 3,
    fontSize: 14,
    fontFamily: 'Roboto',
  },

  picker: {
    width: '80%',
    height: 50,
    color: '#000000',
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    borderWidth: 2,
    elevation: 3,
  },

  botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },

  image: {
    width: 300,
    height: 200,
    marginBottom: 30,
    borderRadius: 20,
  },
});

export default CadastroProduto;
