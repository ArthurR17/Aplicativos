//Importação das bibliotecas do react
import React, { useState } from 'react';
import {Text, View, StyleSheet, Image, TouchableOpacity, TextInput, Alert, ImageBackground} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';


const Login = ({ navigation}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');


const handleLogin = async () => {
  if (username.trim() === '' || password.trim() === '') {
  Alert.alert('Erro', 'Por favor, preencha todos os campos.');
  return;
    }

  try {
    let users = await AsyncStorage.getItem('users');
    users = users ? JSON.parse(users) : [];
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
      navigation.navigate('OpcoesCli');
    } else {
      alert('Credenciais inválidas!');
    }
  } catch (error) {
    console.error('Failed to login', error);
    alert('Ocorreu um erro ao fazer login.');
  }
};
  return(
    <View style={styles.container}>
            <ImageBackground
        style={styles.back}
        source={require('../assets/fundo.png')}
      />

      <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />
      <TextInput
        style={styles.campo}
        placeholder="Nome de Usuário"
        placeholderTextColor="#9EB9CC"
        value={username}
        onChangeText={setUsername}
      />
      
      <TextInput
        style={styles.campo}
        placeholder="Senha"
        placeholderTextColor="#9EB9CC"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity style={styles.buttonContainer} onPress={handleLogin}>
        <Text style={styles.botao}>Entrar</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('Registrar')}>
        <Text style={styles.botao}>Registrar</Text>
      </TouchableOpacity>
    </View>
  );
}

export default Login;

const styles = StyleSheet.create({
      back: {
    zIndex: -1,
    width: '110%',
    height: '110%',
    position: 'absolute',
  },
  
  campo: {
    width: '80%',
    height: 50,
    color: '#000000',
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderWidth: 2,
    elevation: 3,
    fontSize: 14,
    fontFamily: 'Roboto',
  },

  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#9EB9CC',
  },

  image: {
    width: 300,
    height: 200,
    marginTop: 120,
    marginBottom: 30,
    borderRadius: 20,
  },

  botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },
});
