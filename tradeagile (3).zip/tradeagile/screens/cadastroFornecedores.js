import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CadastroFornecedor = ({ navigation }) => {
  // Estados para armazenar as informações do formulário
  const [nomeFornecedor, setNomeFornecedor] = useState('');
  const [cnpjFornecedor, setCnpjFornecedor] = useState('');
  const [contatoFornecedor, setContatoFornecedor] = useState('');
  const [enderecoFornecedor, setEnderecoFornecedor] = useState('');

  // Função para lidar com o cadastro de fornecedor
  const handleCadastro = async () => {
    // Cria um novo objeto de fornecedor com base nos dados fornecidos
    const novoFornecedor = {
      id: Date.now().toString(),
      name: nomeFornecedor,
      contact: contatoFornecedor,
      cnpj: cnpjFornecedor,
      endereco: enderecoFornecedor,
    };

    try {
      // Obtém os fornecedores existentes no AsyncStorage
      const fornecedoresExistentes = await AsyncStorage.getItem('fornecedores');
      const fornecedores = fornecedoresExistentes ? JSON.parse(fornecedoresExistentes) : [];

      // Adiciona o novo fornecedor à lista existente
      fornecedores.push(novoFornecedor);

      // Armazena a lista atualizada de fornecedores no AsyncStorage
      await AsyncStorage.setItem('fornecedores', JSON.stringify(fornecedores));

      // Exibe uma mensagem de sucesso e navega para a tela de opções
      Alert.alert('Sucesso', 'Fornecedor cadastrado com sucesso!');
      navigation.navigate('OpcoesFunc'); 
    } catch (error) {
      // Exibe uma mensagem de erro caso o cadastro falhe
      Alert.alert('Erro', 'Não foi possível cadastrar o fornecedor.');
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground
        style={styles.back}
        source={require('../assets/fundo.png')}
      />

      <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />

      <TextInput
        style={styles.input}
        placeholder="Nome do Fornecedor"
                        placeholderTextColor="black"
        value={nomeFornecedor}
        onChangeText={setNomeFornecedor}
      />
      <TextInput
        style={styles.input}
        placeholder="CNPJ"
                        placeholderTextColor="black"

        value={cnpjFornecedor}
        onChangeText={setCnpjFornecedor}
      />
      <TextInput
        style={styles.input}
        placeholder="Contato do Fornecedor"
                        placeholderTextColor="black"

        value={contatoFornecedor}
        onChangeText={setContatoFornecedor}
      />
      <TextInput
        style={styles.input}
        placeholder="Endereço"
                        placeholderTextColor="black"

        value={enderecoFornecedor}
        onChangeText={setEnderecoFornecedor}
      />

      <TouchableOpacity style={styles.buttonContainer} onPress={handleCadastro}>
        <Text style={styles.botao}>Cadastrar Fornecedor</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    width: 300,
    height: 200,
    marginBottom: 30,
    borderRadius: 20,
  },
  back: {
    zIndex: -1,
    width: '110%',
    height: '110%',
    position: 'absolute',
  },

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9EB9CC',
  },

  input: {
    width: '80%',
    height: 50,
    color: '#000000',
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderWidth: 2,
    elevation: 3,
    fontSize: 14,
    fontFamily: 'Roboto',
  },
  
  botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },
});

export default CadastroFornecedor;
