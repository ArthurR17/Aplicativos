import React, { useState } from 'react';
import { View, Text, FlatList, Alert, StyleSheet, TouchableOpacity, Image, ImageBackground, ScrollView } from 'react-native';
import { jsPDF } from 'jspdf';
import * as FileSystem from 'expo-file-system';

// Importar o logo
const logo = require('../assets/trade.agilefundo.png'); // Caminho correto para a imagem do logo
const backgroundImg = require('../assets/fundo.png'); // Caminho da imagem de fundo

const CheckoutScreen = ({ route , navigation}) => {
  const { cart: initialCart } = route.params;
  const [cart, setCart] = useState(initialCart);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [showPaymentOptions, setShowPaymentOptions] = useState(false);

  const calculateTotal = () => {
    let total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    if (paymentMethod === 'debit' || paymentMethod === 'credit') {
      total += total * 0.1; // Adiciona 10% para pagamento com cartão
    }
    return total.toFixed(2);
  };

  const handleQuantityChange = (id, action) => {
    const updatedCart = cart.map((item) => {
      if (item.id === id) {
        if (action === 'increase') {
          return { ...item, quantity: item.quantity + 1 };
        } else if (action === 'decrease' && item.quantity > 1) {
          return { ...item, quantity: item.quantity - 1 };
        }
      }
      return item;
    });
    setCart(updatedCart);
  };

  const handleDeleteItem = (id) => {
    const updatedCart = cart.filter((item) => item.id !== id);
    setCart(updatedCart);
  };

  const handlePayment = async () => {
    Alert.alert(
      'Pedido Finalizado',
      `Forma de pagamento: ${paymentMethod === 'cash' ? 'Dinheiro' : paymentMethod}\nTotal: R$ ${calculateTotal()}`
    );
    try {
      await generatePDF();
    } catch (error) {
      console.error('Error generating PDF', error);
      Alert.alert('Erro', 'Ocorreu um erro ao gerar o PDF.');
    }
  };

  const generatePDF = async () => {
    try {
      const doc = new jsPDF();
      // Título
      doc.setFontSize(18);
      doc.text('Resumo do Pedido', 10, 10);
      // Adicionar linhas de produtos
      doc.setFontSize(12);
      cart.forEach((item, index) => {
        doc.text(`${item.name} ${item.quantity} x R$ ${item.price.toFixed(2)}`, 10, 20 + (index * 10));
      });
      // Total
      doc.text(`Total: R$ ${calculateTotal()}`, 10, 20 + (cart.length * 10));
      // Forma de pagamento
      doc.text(`Forma de pagamento: ${paymentMethod === 'cash' ? 'Dinheiro' : paymentMethod}`, 10, 30 + (cart.length * 10));
      // Rodapé
      doc.setFontSize(10);
      doc.text('Obrigado pela sua compra!', 10, 290);
      // Gerar PDF em base64
      const pdfBase64 = doc.output('datauristring');
      const uri = FileSystem.documentDirectory + 'pedido.pdf';
      await FileSystem.writeAsStringAsync(uri, pdfBase64.split(',')[1], { encoding: FileSystem.EncodingType.Base64 });
      Alert.alert('Pedido Finalizado', `Resumo do pedido:\n${cart.map(item => `${item.name} ${item.quantity} x R$ ${item.price.toFixed(2)}`).join('\n')}\nTotal: R$ ${calculateTotal()}\n\nPedido salvo em: ${uri}`);
    } catch (error) {
      console.error('Error generating PDF', error);
      throw error;
    }
  };

  return (
    <ImageBackground source={backgroundImg} style={styles.background}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.overlay}>
          <View style={styles.container}>
            <View style={styles.header}>
              <Image source={logo} style={styles.logo} />
              <Text style={styles.title}>NOTA FISCAL</Text>
            </View>
            <FlatList
              data={cart}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View style={styles.item}>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemDetails}>PREÇO UNITÁRIO R$ {item.price.toFixed(2)}</Text>
                  <View style={styles.quantityControl}>
                    <TouchableOpacity onPress={() => handleQuantityChange(item.id, 'decrease')} style={styles.quantityButton}>
                      <Text style={styles.quantityButtonText}>-</Text>
                    </TouchableOpacity>
                    <Text style={styles.quantityText}>{item.quantity}</Text>
                    <TouchableOpacity onPress={() => handleQuantityChange(item.id, 'increase')} style={styles.quantityButton}>
                      <Text style={styles.quantityButtonText}>+</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => handleDeleteItem(item.id)} style={styles.deleteButton}>
                      <Text style={styles.deleteButtonText}>DELETAR</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            />
            <Text style={styles.total}>TOTAL: R$ {calculateTotal()}</Text>
            <TouchableOpacity
              style={styles.paymentButton}
              onPress={() => setShowPaymentOptions(!showPaymentOptions)}
            >
              <Text style={styles.paymentButtonText}>FORMAS DE PAGAMENTO</Text>
            </TouchableOpacity>
            {showPaymentOptions && (
              <View style={styles.paymentOptions}>
                <TouchableOpacity
                  style={[styles.paymentOptionButton, paymentMethod === 'cash' && styles.selectedOption]}
                  onPress={() => setPaymentMethod('cash')}
                >
                  <Text style={styles.paymentOptionText}>PIX</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.paymentOptionButton, paymentMethod === 'debit' && styles.selectedOption]}
                  onPress={() => setPaymentMethod('debit')}
                >
                  <Text style={styles.paymentOptionText}>DÉBITO</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.paymentOptionButton, paymentMethod === 'credit' && styles.selectedOption]}
                  onPress={() => setPaymentMethod('credit')}
                >
                  <Text style={styles.paymentOptionText}>CRÉDITO</Text>
                </TouchableOpacity>
              </View>
            )}
            <TouchableOpacity style={styles.finalizeButton} onPress={handlePayment}>
              <Text style={styles.finalizeButtonText}>FINALIZAR PEDIDO</Text>
            </TouchableOpacity>
          </View>
                <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('Produtos')}>
        <Text style={styles.botao}>Voltar para os Produtos</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('OpcoesCli')}>
        <Text style={styles.botao}>Página Inicial</Text>
      </TouchableOpacity>
        </View>

      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
        botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    marginBottom: 20,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },
  
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)', // Sombra mais sutil para o fundo
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: '90%',
    padding: 20,
    backgroundColor: '#1E5E8B', // Fundo baseado na paleta (#004AAD)
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 35,
    marginBottom: 15,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    justifyContent: 'center',
  },
  logo: {
    width: 110,
    height: 90,
    marginRight: 10,
  },
  title: {
    fontSize: 32,
    color: '#FFDE59', // Título com a cor amarela da paleta
    fontWeight: 'bold',
  },
  item: {
    borderBottomWidth: 2,
    borderBottomColor: '#9EB9CC', // Linha de separação usando a cor #9EB9CC
    paddingVertical: 10,
    marginBottom: 10,
    width: '100%',
    alignItems: 'center',
  },
  itemName: {
    fontSize: 18,
    color: '#FFDE59', // Nome do item em amarelo
    fontWeight: 'bold',
  },
  itemDetails: {
    fontSize: 16,
    color: '#FFFFFF', // Detalhes do item em branco
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  quantityButton: {
    backgroundColor: '#1E5E8B',
    borderRadius: 5,
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginHorizontal: 5,
  },
  quantityButtonText: {
    fontSize: 24,
    color: '#FFFFFF',
  },
  quantityText: {
    fontSize: 18,
    color: '#FFFFFF', // Texto da quantidade em branco
    marginHorizontal: 10,
  },
  deleteButton: {
    backgroundColor: 'red', // Botão de deletar em vermelho
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
    marginLeft: 10,
  },
  deleteButtonText: {
    color: '#FFFFFF', // Texto do botão de deletar em branco
    fontWeight: 'bold',
  },
  total: {
    fontSize: 24,
    color: 'white', // Total em branco
    fontWeight: 'bold',
    marginVertical: 20,
  },
  paymentButton: {
    backgroundColor: '#FFDE59',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginVertical: 10,
    alignItems: 'center',
  },
  paymentButtonText: {
    color: 'black', 
    fontWeight: 'bold',
  },
  paymentOptions: {
    width: '100%',
    marginVertical: 10,
  },
  paymentOptionButton: {
    backgroundColor: 'transparent', // Remover a cor de fundo
    borderColor: '#9EB9CC', // Cor da borda
    borderWidth: 2, // Largura da borda
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginVertical: 5,
    alignItems: 'center',
    position: 'relative',
  },
  paymentOptionText: {
    color: 'white', 
    fontWeight: 'bold',
  },
  selectedOption: {
    borderColor: '#FFDE59', // Borda amarela para a opção selecionada
    backgroundColor: 'transparent', // Manter o fundo transparente
  },
  finalizeButton: {
    backgroundColor: '#FFDE59', // Botão de finalizar pedido com amarelo
    paddingHorizontal: 45,
    paddingVertical: 10,
    borderRadius: 5,
    marginVertical: 20,
    alignItems: 'center',
  },
  finalizeButtonText: {
    color: '#000000', // Texto do botão de finalizar em preto
    fontWeight: 'bold',
  },
});

export default CheckoutScreen;
