import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, ImageBackground, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TabelaFornecedores = ({ navigation }) => {
  const [fornecedores, setFornecedores] = useState([]);

  // Carrega os fornecedores do AsyncStorage ao montar o componente
  useEffect(() => {
    const loadFornecedores = async () => {
      try {
        const storedFornecedores = await AsyncStorage.getItem('fornecedores');
        const parsedFornecedores = storedFornecedores ? JSON.parse(storedFornecedores) : [];
        setFornecedores(parsedFornecedores);
      } catch (error) {
        console.error('Failed to load suppliers:', error);
      }
    };

    loadFornecedores();
  }, []);

  return (
    <ImageBackground
      style={styles.back}
      source={require('../assets/fundo.png')}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Image style={styles.image} source={require('../assets/trade.agilefundo.png')} />
        <Text style={styles.title}>Tabela de Fornecedores</Text>
        <ScrollView horizontal={true} style={styles.tableContainer}>
          <View style={styles.table}>
            <View style={styles.headerRow}>
              <Text style={styles.headerCell}>Fornecedor</Text>
              <Text style={styles.headerCell}>CNPJ</Text>
              <Text style={styles.headerCell}>Contato</Text>
              <Text style={styles.headerCell}>Endereço</Text>
            </View>
            {fornecedores.length === 0 ? (
              <Text style={styles.emptyMessage}>Nenhum fornecedor cadastrado.</Text>
            ) : (
              fornecedores.map((fornecedor) => (
                <View key={fornecedor.id} style={styles.row}>
                  <Text style={styles.cell}>{fornecedor.name}</Text>
                  <Text style={styles.cell}>{fornecedor.cnpj}</Text>
                  <Text style={styles.cell}>{fornecedor.contact}</Text>
                  <Text style={styles.cell}>{fornecedor.endereco}</Text>
                </View>
              ))
            )}
          </View>
        </ScrollView>
      <TouchableOpacity style={styles.buttonContainer} onPress={() => navigation.navigate('OpcoesFunc')}>
        <Text style={styles.botao}>Voltar</Text>
      </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
      botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },
  
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#FFFFFF',
    textAlign: 'center',
  },
  tableContainer: {
    marginBottom: 30,
  },
  table: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    marginRight: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  headerRow: {
    flexDirection: 'row',
    backgroundColor: '#1E5E8B',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#0056b3',
  },
  headerCell: {
    flex: 1,
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 16,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: 'row',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  cell: {
    flex: 1,
    color: '#333',
    textAlign: 'center',
    fontSize: 14,
    paddingHorizontal: 5,
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#888',
    marginVertical: 20,
    fontSize: 16,
    fontStyle: 'italic',
  },
  image: {
    width: 300,
    height: 200,
    marginBottom: 30,
    borderRadius: 20,
  },
  back: {
    zIndex: -1,
    width: '110%',
    height: '100%',
    position: 'absolute',
  },
});

export default TabelaFornecedores;
