import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, TouchableOpacity, Text, Image, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Registrar = ({ navigation }) => {
  const [name, setName] =  useState('');
  const [surname, setSurname] =  useState('');
  const [email, setEmail] =  useState('');
  const [username, setUsername] =  useState('');
  const [password, setPassword] =  useState('');


const handleRegister = async () => {
  try {
    const newUser = { name, surname, email, username, password}
    let users = await AsyncStorage.getItem('users');
    users = users ? JSON.parse(users) : [];
    users.push(newUser);
    await AsyncStorage.setItem('users', JSON.stringify(users));
    navigation.navigate('Login');
  } catch (error) {
    console.error('Failed to register user', error);
    alert('Ocorreu um erro ao registrar o usuário.');
  }
};

return (
  <View style={styles.container}>
                    <ImageBackground
        style={styles.back}
        source={require('../assets/fundo.png')}
      />
      
    <Image style={styles.image} source={require('../assets/trade.agile.png')}/>
    <TextInput
      style={styles.input}
      placeholder="Nome"
      placeholderTextColor="#9EB9CC"
      value={name}
      onChangeText={setName}
    />
    <TextInput
      style={styles.input}
      placeholder="Sobrenome"
      placeholderTextColor="#9EB9CC"
      value={surname}
      onChangeText={setSurname}
    />
    <TextInput
      style={styles.input}
      placeholder="Email"
      placeholderTextColor="#9EB9CC"
      value={email}
      onChangeText={setEmail}
    />
    <TextInput
      style={styles.input}
      placeholder="Usuário"
      placeholderTextColor="#9EB9CC"
      value={username}
      onChangeText={setUsername}
    />
    <TextInput
      style={styles.input}
      placeholder="Senha"
      placeholderTextColor="#9EB9CC"
      secureTextEntry
      value={password}
      onChangeText={setPassword}
    />

    <TouchableOpacity style={styles.buttonContainer} onPress={handleRegister}>
      <Text style={styles.botao}>Registrar</Text>
    </TouchableOpacity>
  </View>
  );
};

const styles = StyleSheet.create({
        back: {
    zIndex: -1,
    width: '110%',
    height: '110%',
    position: 'absolute',
  },

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9EB9CC',
  },

  input: {
    width: '80%',
    height: 50,
    color: '#000000',
    backgroundColor: '#FFFFFF',
    borderColor: '#1E5E8B',
    borderRadius: 10,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderWidth: 2,
    elevation: 3,
    fontSize: 14,
    fontFamily: 'Roboto',
  },
  
  botao: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Roboto',
  },

  buttonContainer: {
    backgroundColor: '#1E5E8B',
    paddingVertical: 15,
    paddingHorizontal: 45,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: '#1E5E8B',
    borderWidth: 2,
    elevation: 5,
    top: 20,
  },

  image: {
  width: 300,
  height: 200,
  marginBottom: 30,
  borderRadius: 20,
  },
});

export default Registrar;
