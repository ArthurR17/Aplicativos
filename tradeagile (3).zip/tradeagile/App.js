//Importação das bibliotecas do rea 
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import login from './screens/login';
import registrar from './screens/registrar';
import home from './screens/home';
import loginFuncionario from './screens/loginFuncionario';
import opcoesFuncionario from './screens/opcoesFuncionario';
import opcoesCliente from './screens/opcoesCliente';
import produtos from './screens/produtos';
import checkout from './screens/checkout';
import tabelaProd from './screens/tabelaProdutos';
import tabelaForn from './screens/tabelaFornecedor';
import cadastroProd from './screens/cadastroProdutos';
import cadastroForn from './screens/cadastroFornecedores';
import contato from './screens/contato';


const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home" screenOptions={{headerShown: false,}} >
        <Stack.Screen name="Login" component={login} />
        <Stack.Screen name="Produtos" component={produtos}/>
        <Stack.Screen name="Checkout" component={checkout}/>
        <Stack.Screen name="LoginFunc" component={loginFuncionario}/>
        <Stack.Screen name="OpcoesFunc" component={opcoesFuncionario}/>
        <Stack.Screen name="OpcoesCli" component={opcoesCliente}/>
        <Stack.Screen name="Registrar" component={registrar}/>
        <Stack.Screen name="Home" component={home}/>
        <Stack.Screen name="TabelaProd" component={tabelaProd}/>
        <Stack.Screen name="TabelaForn" component={tabelaForn}/>
        <Stack.Screen name="CadastroProd" component={cadastroProd}/>
        <Stack.Screen name="CadastroForn" component={cadastroForn}/>
        <Stack.Screen name="Contato" component={contato}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
